FILENAME = "SRP888888"
CLUSTER = "cluster_9"
round=1
source("/home/ambre-aurore/bin/Fish_And_Chips_AAJ/Dataset_insertion_process/2-clusterisationEDC/outliers_correction/test_outliers_et_bruit.R") 
